export const API_SERVER = process.env.REACT_APP_API_SERVER || "http://localhost:4000";
export const VIDEO_SERVER = process.env.REACT_APP_VIDEO_SERVER || "http://localhost:4001";
